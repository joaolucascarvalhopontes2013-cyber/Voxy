# Voxy

Projeto web do **Voxy** — jogue, converse e conecte-se.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub, por exemplo: `voxy`.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. No GitHub, abra **Settings > Pages**.
4. Em **Build and deployment**, escolha:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
5. Salve.
6. Aguarde alguns instantes e abra o endereço publicado pelo GitHub Pages.

## Arquivos

- `index.html` — aplicativo Voxy
- `manifest.json` — configurações para instalação como PWA
- `sw.js` — service worker
- `icons/` — ícones do aplicativo

## Observação importante sobre chamadas

O Voxy usa WebRTC e PeerJS. Para câmera e microfone, abra o aplicativo por HTTPS.
GitHub Pages já fornece HTTPS.

A sinalização via PeerJS depende de internet.
